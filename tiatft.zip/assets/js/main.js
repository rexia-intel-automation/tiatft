// /assets/js/main.js

document.addEventListener('DOMContentLoaded', () => {
  // Espaço reservado para interações globais (smooth scroll, etc).
});
