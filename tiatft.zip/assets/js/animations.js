// /assets/js/animations.js

document.addEventListener('DOMContentLoaded', () => {
  // Placeholder para futuros observers / animações.
});
