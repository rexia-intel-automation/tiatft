// /assets/js/analytics.js

document.addEventListener('DOMContentLoaded', () => {
  // Placeholder para eventos de analytics (n8n, GA4, etc).
});
