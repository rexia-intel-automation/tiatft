<?php
// /components/footer.php
?>
<footer class="site-footer">
    <small>&copy; <?php echo date('Y'); ?> TIATFT — There Is a Template For That. All rights reserved.</small>
</footer>
