<?php
// /config/settings.php

return [
    'webhook_url'    => 'https://primary-production-55af6.up.railway.app/webhook/b52b4ed4-caa5-409b-aadc-e5f920642add',
    'webhook_source' => 'tiaft_landing_waitlist',
];
