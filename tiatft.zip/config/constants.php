<?php
// /config/constants.php

define('TIATFT_SITE_NAME', 'TIATFT - There Is a Template For That');
define('TIATFT_TAGLINE', 'The Universal Template Marketplace');
define('TIATFT_LAUNCH_TEXT', 'Public launch planned for March 2026.');
