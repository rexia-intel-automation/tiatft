<?php
// /templates/open-graph.php
?>
<meta property="og:type" content="website">
<meta property="og:title" content="<?php echo TIATFT_SITE_NAME; ?>">
<meta property="og:description" content="Every digital template. One platform.">
<meta property="og:url" content="https://example.com/">
<meta property="og:image" content="https://i.imgur.com/JBdYUGM.png">
