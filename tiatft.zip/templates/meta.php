<?php
// /templates/meta.php
?>
<meta name="description" content="There Is a Template For That (TIATFT) — the universal template marketplace for automation, apps, workspaces and AI agents.">
<meta name="keywords" content="templates, marketplace, n8n, bubble, notion, automation, AI, TIATFT">
<meta name="author" content="TIATFT">
